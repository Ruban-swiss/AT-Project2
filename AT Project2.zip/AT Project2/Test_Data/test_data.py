# This file consists of Test Information like username, password, XPATH etc

# Python Class for Username and Password
class Data:
    username = "Admin"
    password = "admin123"

# Python Class for Selenium Selectors
class Selectors:
    input_box_username = "username"
    input_box_password = "password"
    login_xpath = '//*[@id="app"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button'