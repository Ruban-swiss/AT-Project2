# This file consists of Test Information like username, password, XPATH etc

# Python Class for Selenium Selectors
class Locators:
    input_box_username = "username"
    input_box_password = "password"
    login_xpath = '//*[@id="app"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button'

    xpath = '//*[@id="app"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[4]/p'
    xpath1 = '//*[@id="app"]/div[1]/div[1]/div/form/div[2]/button[2]'
    xpath2 = '//*[@id="app"]//div[contains(@class, "message success")]/h6'



